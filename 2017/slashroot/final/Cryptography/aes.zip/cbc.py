import random
from string import printable as char
from os.path import getctime as time
from Crypto.Cipher import AES

PAD = '\x00'
SIZE = 16
MODE = AES.MODE_CBC

def getRandom(N):
    return ''.join(random.choice(char) for a in range(N))

def generate(file):
    random.seed(int(time(file)))
    key = getRandom(SIZE)
    iv = getRandom(SIZE)
    print 'KEY\t:', key.encode('hex')
    print 'IV\t:', iv.encode('hex')

    return key, iv

def addPadding(data):
    padsize = SIZE - len(data) % SIZE
    padding = data + PAD * padsize

    return padding

def encrypt(file):
    with open(file, 'rb') as bin:
        data = addPadding(bin.read())

    key, iv = generate(file)
    aes = AES.new(key, MODE, iv)
    enc = aes.encrypt(data)

    with open(file + '.enc', 'wb') as bin:
        bin.write(enc)

def main():
    encrypt('flag')

if __name__ == '__main__':
    main()